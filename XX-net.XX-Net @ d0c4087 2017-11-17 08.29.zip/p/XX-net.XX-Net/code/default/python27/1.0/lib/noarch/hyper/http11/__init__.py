# -*- coding: utf-8 -*-
"""
hyper/http11
~~~~~~~~~~~~

The HTTP/1.1 submodule that powers hyper.
"""
