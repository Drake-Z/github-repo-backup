/**
 * Configuration for jstd scenario adapter 
 */
var jstdScenarioAdapter = {
  relativeUrlPrefix: '/test/e2e/'
};
