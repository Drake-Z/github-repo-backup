Removed according to regulations.
