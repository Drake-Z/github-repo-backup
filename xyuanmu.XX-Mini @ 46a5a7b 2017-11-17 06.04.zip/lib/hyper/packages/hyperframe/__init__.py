# -*- coding: utf-8 -*-
"""
hyperframe
~~~~~~~~~~

A module for providing a pure-Python HTTP/2 framing layer.
"""
__version__ = '2.1.0'
