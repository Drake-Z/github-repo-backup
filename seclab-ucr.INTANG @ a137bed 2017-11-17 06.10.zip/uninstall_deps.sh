#!/bin/bash
#sudo apt-get update
sudo apt-get purge -y libnetfilter-queue-dev libnfnetlink-dev redis-server libhiredis-dev libev-dev python-redis python-scapy

