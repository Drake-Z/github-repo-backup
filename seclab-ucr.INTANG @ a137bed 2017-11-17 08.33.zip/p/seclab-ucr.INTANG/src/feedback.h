
#ifndef __FEEDBACK_H__
#define __FEEDBACK_H__

/*
 * Feedback module
 */


int upload_log();


 #endif

