

void test_cache();

