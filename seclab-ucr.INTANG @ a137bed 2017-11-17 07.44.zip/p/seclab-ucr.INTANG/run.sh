#!/bin/bash

sudo ./bin/intangd $1 || echo "intangd not found. Maybe run make first."



