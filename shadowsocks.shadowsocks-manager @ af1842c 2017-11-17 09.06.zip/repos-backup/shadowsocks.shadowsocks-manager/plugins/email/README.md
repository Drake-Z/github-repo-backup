# email plugin

This plugin can send email to users. You can use it to send verification codes. It can not use alone, must be use with other plugins.
